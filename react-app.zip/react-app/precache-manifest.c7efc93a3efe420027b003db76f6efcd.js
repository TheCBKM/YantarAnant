self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a6682022c11b1cb4f6a8682e87983ae4",
    "url": "./index.html"
  },
  {
    "revision": "c718324537b2232ff853",
    "url": "./static/css/2.a6ea2dfd.chunk.css"
  },
  {
    "revision": "9abfc16bc33aed1b885b",
    "url": "./static/css/main.cfaad20a.chunk.css"
  },
  {
    "revision": "c718324537b2232ff853",
    "url": "./static/js/2.824dae83.chunk.js"
  },
  {
    "revision": "9abfc16bc33aed1b885b",
    "url": "./static/js/main.be1a79af.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "b11321c80fb64c047935457de6ef44ec",
    "url": "./static/media/AsphaltPaver.b11321c8.png"
  },
  {
    "revision": "d1ec297483519225a607eeeca343ecbb",
    "url": "./static/media/Backhoe-Loader.d1ec2974.png"
  },
  {
    "revision": "6fb28fd16506072a275e66fb65995e1c",
    "url": "./static/media/Excavator.6fb28fd1.png"
  },
  {
    "revision": "4697ede02ee7db580f0b5c1ea45edeb3",
    "url": "./static/media/Pilinganddrillingrig.4697ede0.png"
  },
  {
    "revision": "5cbadd6020016be40e7227f75fc36fed",
    "url": "./static/media/Rideonroller.5cbadd60.png"
  },
  {
    "revision": "159a267e52dc78911c98c3fb2b4ebc60",
    "url": "./static/media/Roller.159a267e.png"
  },
  {
    "revision": "178284dfaca1c37f0b5d6583509b7b47",
    "url": "./static/media/Selfloadingmixer.178284df.png"
  },
  {
    "revision": "083568fe30b9bf2d754f0dee04245fc7",
    "url": "./static/media/Slipformpaver.083568fe.png"
  },
  {
    "revision": "1e1860d9406cfaba7fb7006a1a7e7c02",
    "url": "./static/media/Tipper.1e1860d9.png"
  },
  {
    "revision": "c11fc2791bccd5c25586927d80bd7d71",
    "url": "./static/media/Towercrane.c11fc279.png"
  },
  {
    "revision": "b24a3d9cfd3025aba8c4939029bd9adf",
    "url": "./static/media/Truck-Mounted-Crane.b24a3d9c.png"
  },
  {
    "revision": "d04eb6842748da419546d17959730ad9",
    "url": "./static/media/Yantranant LOGO-01.d04eb684.png"
  },
  {
    "revision": "2286c38ea6d363b3596b9391f2c6f6a5",
    "url": "./static/media/add1.2286c38e.jpg"
  },
  {
    "revision": "29f5e9151ad49d110615bf7f17be41f8",
    "url": "./static/media/architecture-black-and-white-buildings-1437493.29f5e915.jpg"
  },
  {
    "revision": "b7ea15da461a2cb06ff23b2902b73695",
    "url": "./static/media/architecture-buildings-business-190417.b7ea15da.jpg"
  },
  {
    "revision": "2e38ba0d6dde0c4df5ff8c22f751f55c",
    "url": "./static/media/boomPlacer.2e38ba0d.png"
  },
  {
    "revision": "4b4424ebd89b769f66d2a802f4f33bef",
    "url": "./static/media/bulldozer-construction-construction-site-259966.4b4424eb.jpg"
  },
  {
    "revision": "696be0ddaba437a6166165a3328326c5",
    "url": "./static/media/concretepump.696be0dd.png"
  },
  {
    "revision": "de378509a9b469e9d125d6def49c033d",
    "url": "./static/media/construction-excavator-site-4510.de378509.jpg"
  },
  {
    "revision": "bb888aac8c04def889f333dd795879b2",
    "url": "./static/media/jcb1.bb888aac.jpg"
  },
  {
    "revision": "690e734940ae1b28f491bcb5c8a08d26",
    "url": "./static/media/logo.690e7349.png"
  },
  {
    "revision": "00520007b7e1635b460b9277b2a3ae0d",
    "url": "./static/media/msgp.00520007.png"
  },
  {
    "revision": "d96a73630805a95a6bada5b386d555bc",
    "url": "./static/media/s1.d96a7363.png"
  },
  {
    "revision": "2e2ac29247efea2e4e1cda3a77dd1448",
    "url": "./static/media/s2.2e2ac292.png"
  },
  {
    "revision": "1e7f82356ecbcac3630ec0fff829bb6b",
    "url": "./static/media/s3.1e7f8235.jpg"
  },
  {
    "revision": "7fc4f7070c0a5408a30d0f14ffc38ed8",
    "url": "./static/media/s4.7fc4f707.jpg"
  },
  {
    "revision": "2723de6c18e8e63d24702192762735ac",
    "url": "./static/media/s5.2723de6c.jpg"
  },
  {
    "revision": "d8de91484baac7430a60969567827069",
    "url": "./static/media/s6.d8de9148.jpeg"
  },
  {
    "revision": "a1858e6bc190e5a2ad7f897e19b1a4ab",
    "url": "./static/media/trailertruck.a1858e6b.png"
  },
  {
    "revision": "60f3025171dc544e1324167f414161cf",
    "url": "./static/media/transit-mixer.60f30251.png"
  }
]);